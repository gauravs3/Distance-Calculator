﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistanceCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            double lat1 = 29.2001991, long1 = 48.0467224, lat2 = 28.668066, long2 = 48.285353;
            double distance = DistanceCalculator.CalcDistance(lat1, long1, lat2, long2);
            Console.WriteLine("Distance is : "+ distance);
            Console.ReadLine();
        }
    }
}
